-- Status:6:23:MP_0:rmsystem:php:1.24.4::5.5.38-0ubuntu0.12.04.1-log:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|media|2|16384||InnoDB
-- TABLE|retailer|5|16384||InnoDB
-- TABLE|tier|4|16384||InnoDB
-- TABLE|tier_transaction|0|32768||InnoDB
-- TABLE|transaction|4|49152||InnoDB
-- TABLE|user|8|16384||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2014-10-16 10:42

--
-- Create Table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `media_id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(45) DEFAULT NULL,
  `value` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `media`
--

/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` (`media_id`,`location`,`value`) VALUES ('1','homepage_image','/img/new.png');
INSERT INTO `media` (`media_id`,`location`,`value`) VALUES ('2','homepage_video','84b43h7t874');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;


--
-- Create Table `retailer`
--

DROP TABLE IF EXISTS `retailer`;
CREATE TABLE `retailer` (
  `retailer_id` int(11) NOT NULL AUTO_INCREMENT,
  `private_key` varchar(256) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`retailer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `retailer`
--

/*!40000 ALTER TABLE `retailer` DISABLE KEYS */;
INSERT INTO `retailer` (`retailer_id`,`private_key`,`name`) VALUES ('1','bacbc6baf49c713067c5801f88c332d95cba70a9','Bestbuy');
INSERT INTO `retailer` (`retailer_id`,`private_key`,`name`) VALUES ('2','cef1f8a61c7ebd455710605f998df7acffa09970','Embry-Riddle Aeronautical University Bookstor');
INSERT INTO `retailer` (`retailer_id`,`private_key`,`name`) VALUES ('3','baaa7838e08ceda9ef9685b23f84c2fc76d13741','Aéropostale');
INSERT INTO `retailer` (`retailer_id`,`private_key`,`name`) VALUES ('4','a46af6931d9dace2200617548fab3274549e308f','Amazon.com');
INSERT INTO `retailer` (`retailer_id`,`private_key`,`name`) VALUES ('6','1c5ddf82c889cc90301ec0e2dcf72646230d67c5','RMSystem.org');
/*!40000 ALTER TABLE `retailer` ENABLE KEYS */;


--
-- Create Table `tier`
--

DROP TABLE IF EXISTS `tier`;
CREATE TABLE `tier` (
  `tier_id` int(9) NOT NULL AUTO_INCREMENT,
  `multiplier` int(9) NOT NULL,
  `enroll_bonus` int(9) NOT NULL,
  `name` varchar(25) NOT NULL,
  PRIMARY KEY (`tier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `tier`
--

/*!40000 ALTER TABLE `tier` DISABLE KEYS */;
INSERT INTO `tier` (`tier_id`,`multiplier`,`enroll_bonus`,`name`) VALUES ('1','1','0','value');
INSERT INTO `tier` (`tier_id`,`multiplier`,`enroll_bonus`,`name`) VALUES ('2','2','5000','gold');
INSERT INTO `tier` (`tier_id`,`multiplier`,`enroll_bonus`,`name`) VALUES ('3','3','15000','platinum');
INSERT INTO `tier` (`tier_id`,`multiplier`,`enroll_bonus`,`name`) VALUES ('4','4','20000','prestige');
/*!40000 ALTER TABLE `tier` ENABLE KEYS */;


--
-- Create Table `tier_transaction`
--

DROP TABLE IF EXISTS `tier_transaction`;
CREATE TABLE `tier_transaction` (
  `tier_transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `tier_user_id` int(11) NOT NULL,
  `new_reward_tier` varchar(45) NOT NULL,
  `tier_transaction_dt` datetime NOT NULL,
  PRIMARY KEY (`tier_transaction_id`),
  KEY `user_id_idx` (`tier_user_id`),
  CONSTRAINT `tier_user_id` FOREIGN KEY (`tier_user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `tier_transaction`
--

/*!40000 ALTER TABLE `tier_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `tier_transaction` ENABLE KEYS */;


--
-- Create Table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `retailer_id` int(11) NOT NULL,
  `amount_spent` varchar(45) NOT NULL DEFAULT '0.00',
  `transaction_dt` datetime NOT NULL,
  `reward_point` int(11) NOT NULL DEFAULT '0',
  `reward_coupon_id` varchar(50) NOT NULL DEFAULT '0',
  `is_redeemed` bit(1) DEFAULT b'0',
  `coupon_gen_dt` datetime NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `retailer_id_idx` (`retailer_id`),
  KEY `user_id_idx` (`user_id`),
  CONSTRAINT `retailer_id` FOREIGN KEY (`retailer_id`) REFERENCES `retailer` (`retailer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

--
-- Data for Table `transaction`
--

/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` (`transaction_id`,`user_id`,`retailer_id`,`amount_spent`,`transaction_dt`,`reward_point`,`reward_coupon_id`,`is_redeemed`,`coupon_gen_dt`) VALUES ('68','56','1','2000','2014-10-13 21:40:03','20','1413254082-56-20','\0','2014-10-13 22:35:13');
INSERT INTO `transaction` (`transaction_id`,`user_id`,`retailer_id`,`amount_spent`,`transaction_dt`,`reward_point`,`reward_coupon_id`,`is_redeemed`,`coupon_gen_dt`) VALUES ('69','56','4','5000','2014-10-13 22:35:48','50','1413254151-56-50','\0','2014-10-13 22:36:05');
INSERT INTO `transaction` (`transaction_id`,`user_id`,`retailer_id`,`amount_spent`,`transaction_dt`,`reward_point`,`reward_coupon_id`,`is_redeemed`,`coupon_gen_dt`) VALUES ('70','56','3','1000','2014-10-13 22:36:54','10','1413254217-56-10','\0','2014-10-13 22:37:09');
INSERT INTO `transaction` (`transaction_id`,`user_id`,`retailer_id`,`amount_spent`,`transaction_dt`,`reward_point`,`reward_coupon_id`,`is_redeemed`,`coupon_gen_dt`) VALUES ('72','56','1','5000','2014-10-14 00:00:29','50','1413261087-56-50','\0','2014-10-14 00:31:30');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;


--
-- Create Table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `address_line_1` varchar(45) DEFAULT NULL,
  `address_line_2` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zip_code` varchar(45) DEFAULT NULL,
  `birth_date` varchar(45) DEFAULT NULL,
  `role` varchar(45) NOT NULL DEFAULT 'member',
  `reward_points` varchar(45) NOT NULL DEFAULT '0',
  `ready_reward_points` varchar(45) NOT NULL DEFAULT '0',
  `reward_tier` varchar(45) DEFAULT 'value',
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) NOT NULL,
  `cc_number` varchar(45) DEFAULT NULL,
  `cc_expire` varchar(45) DEFAULT NULL,
  `cc_cvv` varchar(45) DEFAULT NULL,
  `activation` varchar(40) DEFAULT NULL,
  `billing_address_line_1` varchar(45) DEFAULT NULL,
  `billing_address_line_2` varchar(45) DEFAULT NULL,
  `billing_city` varchar(45) DEFAULT NULL,
  `billing_state` varchar(45) DEFAULT NULL,
  `billing_zip` varchar(45) DEFAULT NULL,
  `registration_dt` datetime DEFAULT NULL,
  `activation_dt` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

--
-- Data for Table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`user_id`,`first_name`,`last_name`,`address_line_1`,`address_line_2`,`city`,`state`,`zip_code`,`birth_date`,`role`,`reward_points`,`ready_reward_points`,`reward_tier`,`email`,`password`,`cc_number`,`cc_expire`,`cc_cvv`,`activation`,`billing_address_line_1`,`billing_address_line_2`,`billing_city`,`billing_state`,`billing_zip`,`registration_dt`,`activation_dt`) VALUES ('49','System','Admin','','','','','','','admin','0','0','value','admin@rmsystem.org','9b8e9af9eb5457efb44fc9c43fb1c1614dfa2039',NULL,NULL,NULL,'b24cea1a3a3191174563153cd0835621',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `user` (`user_id`,`first_name`,`last_name`,`address_line_1`,`address_line_2`,`city`,`state`,`zip_code`,`birth_date`,`role`,`reward_points`,`ready_reward_points`,`reward_tier`,`email`,`password`,`cc_number`,`cc_expire`,`cc_cvv`,`activation`,`billing_address_line_1`,`billing_address_line_2`,`billing_city`,`billing_state`,`billing_zip`,`registration_dt`,`activation_dt`) VALUES ('50','Rashmi','Raskar','','','','','','','admin','0','0','value','raskarr@rmsystem.org','6cfffe73cb889afc8b68d9cd88757d2664ef4f16',NULL,NULL,NULL,'30fcd3220588e84f59929801cd4141d0',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `user` (`user_id`,`first_name`,`last_name`,`address_line_1`,`address_line_2`,`city`,`state`,`zip_code`,`birth_date`,`role`,`reward_points`,`ready_reward_points`,`reward_tier`,`email`,`password`,`cc_number`,`cc_expire`,`cc_cvv`,`activation`,`billing_address_line_1`,`billing_address_line_2`,`billing_city`,`billing_state`,`billing_zip`,`registration_dt`,`activation_dt`) VALUES ('51','Nathan','Feeser','','','','','','','admin','0','0','value','feesern@rmsystem.org','0c532130dfae02e314ae036b5828074ca5d1810c',NULL,NULL,NULL,'c95d09c2ba2ccde45e15c00ec9689ce1',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `user` (`user_id`,`first_name`,`last_name`,`address_line_1`,`address_line_2`,`city`,`state`,`zip_code`,`birth_date`,`role`,`reward_points`,`ready_reward_points`,`reward_tier`,`email`,`password`,`cc_number`,`cc_expire`,`cc_cvv`,`activation`,`billing_address_line_1`,`billing_address_line_2`,`billing_city`,`billing_state`,`billing_zip`,`registration_dt`,`activation_dt`) VALUES ('52','Ziyi','Wang','','','','','','','admin','0','0','value','wangz@rmsystem.org','ebbcc06b34478cd4cbce58348f969b235d04c847',NULL,NULL,NULL,'54273875de9f0df47c40a9a91f6c6513',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `user` (`user_id`,`first_name`,`last_name`,`address_line_1`,`address_line_2`,`city`,`state`,`zip_code`,`birth_date`,`role`,`reward_points`,`ready_reward_points`,`reward_tier`,`email`,`password`,`cc_number`,`cc_expire`,`cc_cvv`,`activation`,`billing_address_line_1`,`billing_address_line_2`,`billing_city`,`billing_state`,`billing_zip`,`registration_dt`,`activation_dt`) VALUES ('53','David','Gluch','','','','','','','admin','0','0','value','gluchd@rmsystem.org','2c777a96a7c2d31dbf8423a1d0a1652ba49c0944',NULL,NULL,NULL,'003a31d1940336b2b3ed0bfb88dcdb8d',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `user` (`user_id`,`first_name`,`last_name`,`address_line_1`,`address_line_2`,`city`,`state`,`zip_code`,`birth_date`,`role`,`reward_points`,`ready_reward_points`,`reward_tier`,`email`,`password`,`cc_number`,`cc_expire`,`cc_cvv`,`activation`,`billing_address_line_1`,`billing_address_line_2`,`billing_city`,`billing_state`,`billing_zip`,`registration_dt`,`activation_dt`) VALUES ('54','John','Doe','600 South Clyde Morrise','','Daytona Beach','FL','32114','10/04/1980','member','0','0','gold','doej@aol.com','bc4de02ea95b0024c4b8f4bd910c38fb9e90d78f','da39a3ee5e6b4b0d3255bfef95601890afd80709','','','97e6095f2e9de950bce0ba02f16b4bbb','','','','','',NULL,NULL);
INSERT INTO `user` (`user_id`,`first_name`,`last_name`,`address_line_1`,`address_line_2`,`city`,`state`,`zip_code`,`birth_date`,`role`,`reward_points`,`ready_reward_points`,`reward_tier`,`email`,`password`,`cc_number`,`cc_expire`,`cc_cvv`,`activation`,`billing_address_line_1`,`billing_address_line_2`,`billing_city`,`billing_state`,`billing_zip`,`registration_dt`,`activation_dt`) VALUES ('56','Rashmi','Raskar','123 Embry Riddle 2','APT 1000','Daytona Beach','FL','32115','09/01/2014','member','0','130','value','raskarr@my.erau.edu','6367c48dd193d56ea7b0baad25b19455e529f5ee','6a3239d36e886830a28e3881517a7b2d2862d847','12/30','112','','','','','','',NULL,NULL);
INSERT INTO `user` (`user_id`,`first_name`,`last_name`,`address_line_1`,`address_line_2`,`city`,`state`,`zip_code`,`birth_date`,`role`,`reward_points`,`ready_reward_points`,`reward_tier`,`email`,`password`,`cc_number`,`cc_expire`,`cc_cvv`,`activation`,`billing_address_line_1`,`billing_address_line_2`,`billing_city`,`billing_state`,`billing_zip`,`registration_dt`,`activation_dt`) VALUES ('59','Nathan','Feeser','1506 Deer Springs Road','','Port Orange','FL','32129','10/14/2014','member','25000','0','prestige','nathanfeeser@gmail.com','dca7fce5d6f4a92446e222bb4fe26225986aafa4','da39a3ee5e6b4b0d3255bfef95601890afd80709','','','','','','','','','2014-10-16 09:39:06','2014-10-16 09:40:00');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

